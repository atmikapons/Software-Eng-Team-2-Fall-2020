There are currently no specific data collection scripts for this project.


Although there are no scripts to run for data collection purposes, one can see that the manager webiste is 
able to collect data from the databases and create graphs from it. This can be seen on the Statistics page
of the website. Furthermore, the manager website generates suggested price settings for the garage based
on average capacity per hour data which is collected from the records table of the database. This is able
to offer predictictions on what multiplier would best suit the price for each hour. Features of the website
can be tested through the unit testing code.
