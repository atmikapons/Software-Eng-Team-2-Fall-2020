package com.example.user.zippypark;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by user on 3/19/2020.
 */

public class EditReservationActivity extends AppCompatActivity {
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_reservation);
    }
}