There are currently no data collection scripts or programs. 


Future Plans:
As we move forward in this project, we aim to integrate data collection aspects so that they can be exhibited by the time of our second demonstration.
Our data collecion features will be displayed through a manager statistics page that is viewable through the manager webiste.
Currently, this page is blank in the manager portal web application.
Values of interest will be demonstrated through charts and graphs that show how these variables change with respect to time.
Purely numerical respresentations and formulas may be displayed as well if the group sees a need for it.

Reasoning for Manager Statistics:
The intention of these statistics will be to see a general trend in the success of the garage based on different measures of success 
such as increase in number of reservations, increase in number of cutsomers, etc.
These graphs should give the manager a general sense of how individual variables affect business. 
It will also allow the manager to gauge on which points the garage is failing to see a positive trend.
Based on this information the manager will be able to implement changes in order to attract cutsomer or encourage favorable actions. 
